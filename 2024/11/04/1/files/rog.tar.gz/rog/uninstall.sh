#!/bin/sh
source /jffs/softcenter/scripts/base.sh

rm -rf /jffs/softcenter/res/icon-rog.png >/dev/null 2>&1
rm -rf /jffs/softcenter/init.d/*rog.sh >/dev/null 2>&1
rm -rf /jffs/softcenter/scripts/rog_*.sh >/dev/null 2>&1 
rm -rf /jffs/softcenter/webs/Module_rog.asp >/dev/null 2>&1
rm -rf /jffs/softcenter/scripts/uninstall_rog >/dev/null 2>&1
rm -rf /tmp/rog* >/dev/null 2>&1
# 将 rax80 的风扇控制程序从根目录移除 rax80/rom/libnvram.so,rax80/usr/sbin/fanCtl
rm -rf /rom/libnvram.so
rm -rf /usr/sbin/fanCtl
