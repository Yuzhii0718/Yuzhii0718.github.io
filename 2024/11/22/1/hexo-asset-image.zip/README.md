# hexo-asset-image

Give asset image in hexo a related path automatically

## Usege

```shell
npm install hexo-asset-image --save
```

I suggest to use hexo-render-markdown-it

You need set hexo config like this:

```yaml
markdown:
  images:
    lazyload: false
    prepend_root: false
    post_asset: false
```

## Example

```shell
MacGesture2-Publish
├── apppicker.jpg
├── logo.jpg
└── rules.jpg
MacGesture2-Publish.md
```

Make sure `post_asset_folder: true` in your `_config.yml`.

eg:

If you create a new post as `MacGesture2-Publishv`.

Then will create a file called `MacGesture2-Publish.md` and a folder named `MacGesture2-Publish`.

You can insert image in the `MacGesture2-Publish.md` like: `![logo](./MacGesture2-Publish/logo.png)`.

Through this method, you can view the image in editor.

## History

2024-11-22: support hexo7.3.0 with hexo-render-markdown-it
