#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

# 用 logging 替代 print 同时保留控制台输出，记录到文件 /tmp/python-script/getip.log
# 通过 git push 命令把 IP 写入到远程仓库 /tmp/python-script/ip.txt
# 远程地址为 git@github.com:Yuzhii0718/Test-Remote-IP.git

import os
import logging
import subprocess
from datetime import datetime
import git


# 如果不存在 /tmp/python-script/ 目录，创建该目录
if not os.path.exists('/tmp/python-script/'):
    os.makedirs('/tmp/python-script/')

# 配置日志记录器
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 创建文件处理器
file_handler = logging.FileHandler('/tmp/python-script/autopush.log')
file_handler.setLevel(logging.INFO)

# 创建控制台处理器
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# 创建格式化器并添加到处理器
formatter = logging.Formatter('%(asctime)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# 添加处理器到日志记录器
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# 替换所有的print函数
def print(*args, **kwargs):
    logger.info(' '.join(map(str, args)))

import subprocess

def get_ip():
    try:
        arp_info = subprocess.check_output(['cat', '/proc/net/arp']).decode('utf-8')
        iwinfo_info = subprocess.check_output(['iwinfo', 'phy1-ap0', 'info']).decode('utf-8')
        assoclist_info = subprocess.check_output(['iwinfo', 'phy1-ap0', 'assoclist']).decode('utf-8')
        station_dump_info = subprocess.check_output(['iw', 'dev', 'phy1-ap0', 'station', 'dump']).decode('utf-8')
        dhcp_leases_info = subprocess.check_output(['cat', '/tmp/dhcp.leases']).decode('utf-8')
        odhcpd_info = subprocess.check_output(['cat', '/tmp/hosts/odhcpd']).decode('utf-8')
        ifconfig_info = subprocess.check_output(['ifconfig']).decode('utf-8')
        ip_info = subprocess.check_output(['ip', 'addr']).decode('utf-8')
        
        print("=" * 80)
        print(f"Start Time: {datetime.now()}")
        print("=" * 80)
        print("Get IP address")
        
        return {
            'arp_info': arp_info,
            'iwinfo_info': iwinfo_info,
            'assoclist_info': assoclist_info,
            'station_dump_info': station_dump_info,
            'dhcp_leases_info': dhcp_leases_info,
            'odhcpd_info': odhcpd_info,
            'ifconfig_info': ifconfig_info,
            'ip_info': ip_info
        }
    except subprocess.CalledProcessError as e:
        print.error(f"An error occurred: {e}")
        return str(e)

def write_ip(info_dict):
    ip_path = '/tmp/python-script/ip.txt'
    try:
        with open(ip_path, 'w') as file:
            # 写入当前时间
            file.write(f"Time: {datetime.now()}\n\n")
            # 写入分割线
            file.write("=" * 80 + "\n\n")
            for key, value in info_dict.items():
                file.write(f"{key}:\n{value}\n\n")
        print("Information written to file successfully.")
        print(f"File path:{ip_path}")
        return True
    except Exception as e:
        print(f"An error occurred: {e}")
        return False

def initialize_repo(repo_path, remote_url, branch_name):
    if not os.path.exists(repo_path):
        os.makedirs(repo_path)
    
    if not os.path.exists(os.path.join(repo_path, '.git')):
        # initialize a new repository
        repo = git.Repo.init(repo_path)
        # create main branch
        repo.git.checkout('-b', branch_name)
        repo.create_remote('origin', remote_url)
    else:
        repo = git.Repo(repo_path)
    
    return repo

def git_push():
    try:
        repo_path = '/tmp/python-script/'
        remote_url = 'git@github.com:Yuzhii0718/Test-Remote-IP.git'
        branch_name = 'main'

        repo = initialize_repo(repo_path, remote_url, branch_name)
        
        repo.git.add('ip.txt')
        repo.git.add('autopush.log')
        repo.git.commit('-m', f'Update IP address: {datetime.now()}')
        repo.git.push('-u', 'origin', branch_name, '--force')
        print("IP address pushed to remote repository.")
        print(f"Repository: {remote_url}, Branch: {branch_name}")
        return True
    except Exception as e:
        print(f"An error occurred: {e}")
        return False

def main():
    ip = get_ip()
    if ip:
        try:
            write_ip(ip)
            print("IP address written to file successfully.")
            git_push()
            print("IP address pushed to remote repository successfully.")
        except Exception as e:
            print(f"An error occurred: {e}")
    else:
        print("Failed to get IP address.")

    print("=" * 80)
    print(f"End Time: {datetime.now()}")
    print("=" * 80)

if __name__ == "__main__":
    main()
