#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# Description: This script truncates log files in a directory if they exceed a certain size.


import os
import logging
from datetime import datetime

# 如果不存在 /tmp/python-script/ 目录，创建该目录
if not os.path.exists('/tmp/python-script/'):
    os.makedirs('/tmp/python-script/')

# 配置日志记录器
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 创建文件处理器
file_handler = logging.FileHandler('/tmp/python-script/autotruncate.log')
file_handler.setLevel(logging.INFO)

# 创建控制台处理器
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# 创建格式化器并添加到处理器
formatter = logging.Formatter('%(asctime)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# 添加处理器到日志记录器
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# 替换所有的print函数
def print(*args, **kwargs):
    logger.info(' '.join(map(str, args)))

def truncate_log_file(file_path):
    with open(file_path, 'r+') as file:
        lines = file.readlines()
        half_size = len(lines) // 2
        file.seek(0)
        file.writelines(lines[half_size:])
        file.truncate()
        print(f"Truncated {file_path}")

def check_log_files(directory, max_size_mb=1):
    max_size_bytes = max_size_mb * 1024 * 1024
    for filename in os.listdir(directory):
        if filename.endswith('.log'):
            file_path = os.path.join(directory, filename)
            if os.path.getsize(file_path) >= max_size_bytes:
                truncate_log_file(file_path)
                print(f"Truncated {file_path}")
            else:
                print(f"Skipping {file_path}")
                

if __name__ == "__main__":
    log_directory = '/tmp/python-script/'
    check_log_files(log_directory)