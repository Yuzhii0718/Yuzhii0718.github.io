#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

import telnetlib
import time
import random
import logging
import os
from datetime import datetime

# 如果不存在 /tmp/python-script/ 目录，创建该目录
if not os.path.exists('/tmp/python-script/'):
    os.makedirs('/tmp/python-script/')

# 配置日志记录器
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 创建文件处理器
file_handler = logging.FileHandler('/tmp/python-script/telnet.log')
file_handler.setLevel(logging.INFO)

# 创建控制台处理器
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# 创建格式化器并添加到处理器
formatter = logging.Formatter('%(asctime)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# 添加处理器到日志记录器
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# 替换所有的print函数
def print(*args, **kwargs):
    logger.info(' '.join(map(str, args)))

class TelnetClient:
    def __init__(self, host, user, password, commands, repeat, min_latency, max_latency):
        self.host = host
        self.user = user
        self.password = password
        self.commands = commands
        self.repeat = repeat
        self.min_latency = min_latency
        self.max_latency = max_latency
        # self.print=print

    def connect(self):
        try:
            self.tn = telnetlib.Telnet(self.host)
            self.tn.read_until(b"Login: ")
            self.tn.write(self.user.encode('ascii') + b"\n")

            if self.password:
                self.tn.read_until(b"Password: ")
                self.tn.write(self.password.encode('ascii') + b"\n")

            print(f"Connected to {self.user}@{self.host}.")
            print("=" * 40)

            self.execute_commands()

            print("=" * 40)
            print("All commands executed.")
            print(f"Repeat {self.repeat} times.")
            self.tn.close()
            print("Connection closed.")
            return True

        except Exception as e:
            print(f"An error occurred: {e}")

    def generate_latency(self):
        latency = random.uniform(self.min_latency, self.max_latency)
        time.sleep(latency)
        return latency

    def execute_commands(self):
        for _ in range(self.repeat):
            for command, interval in self.commands:
                latency = self.generate_latency()
                print(f"Random latency: {latency:.2f} seconds")
                print(f"Executing command: {command}")
                self.tn.write(command.encode('ascii') + b"\n")
                for i in range(interval, 0, -1):
                    print(f"Next command in {i} seconds...", end='\r')
                    time.sleep(1)
                print(f"Waiting for {latency} seconds before executing the next command.")
            print()


def main():
    host = "192.168.1.1"
    user = "admin"
    password = "lzc6584567"
    commands = [("ifconfig eth2 down", 2), ("ifconfig eth2 up", 2)]
    repeat = 2
    min_latency = 1
    max_latency = 3

    print("=" * 40)
    print("Starting TelnetClient...")
    print("Current Time:", datetime.now())
    print("=" * 40)

    client = TelnetClient(host, user, password, commands, repeat, min_latency, max_latency)
    client.connect()

    print("=" * 40)
    print("END Time:", datetime.now())
    print("=" * 40)


if __name__ == "__main__":
    main()
