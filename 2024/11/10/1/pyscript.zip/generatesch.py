#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# This script generates random cron jobs for the latency-simula.py script.

import random
import logging
from datetime import datetime
import os

# 如果不存在 /tmp/python-script/ 目录，创建该目录
if not os.path.exists('/tmp/python-script/'):
    os.makedirs('/tmp/python-script/')

# 配置日志记录器
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 创建文件处理器
file_handler = logging.FileHandler('/tmp/python-script/gensch.log')
file_handler.setLevel(logging.INFO)

# 创建控制台处理器
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

# 创建格式化器并添加到处理器
formatter = logging.Formatter('%(asctime)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# 添加处理器到日志记录器
logger.addHandler(file_handler)
logger.addHandler(console_handler)

# 替换所有的print函数
def print(*args, **kwargs):
    logger.info(' '.join(map(str, args)))

def read_crontab(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    return lines

def write_crontab(file_path, lines):
    with open(file_path, 'w') as file:
        file.writelines(lines)

def remove_latency_simula(lines):
    new_lines = [line for line in lines if 'latency-simula.py' not in line]
    removed_count = len(lines) - len(new_lines)
    if removed_count > 0:
        print(f"Removed {removed_count} latency-simula.py commands.")
    else:
        print("No latency-simula.py commands found.")
    return new_lines

def generate_random_times(start_hour, end_hour, num_commands, min_interval, max_interval, offset):
    times = []
    used_times = set()
    total_minutes = (end_hour - start_hour + offset) * 60
    max_possible_commands = total_minutes // max_interval

    if num_commands > max_possible_commands:
        print(f"Reducing number of commands from {num_commands} to {max_possible_commands} due to time constraints.")
        num_commands = max_possible_commands

    current_minute = random.randint(0, max_interval)
    for _ in range(num_commands):
        while True:
            hour = start_hour + current_minute // 60
            minute = current_minute % 60
            if (minute, hour) not in used_times:
                used_times.add((minute, hour))
                times.append((minute, hour))
                break
            current_minute += random.randint(min_interval, max_interval)
            if current_minute >= total_minutes:
                current_minute = random.randint(0, max_interval)

    return times

def generate_cron_commands(times):
    commands = []
    for minute, hour in times:
        command = f"{minute} {hour} * * * /usr/bin/python3 /usr/bin/latency-simula.py\n"
        commands.append(command)
        print(f"Generated command: {command.strip()}")
    return commands

def main():
    file_path = '/etc/crontabs/root'
    start_hour = 8
    end_hour = 24
    # Offset in hours, in order to fix time constraints
    offset = 3
    num_commands = 60
    min_interval = 20
    max_interval = 30

    print("=" * 40)
    print(f"Script started at {datetime.now()}")
    print("=" * 40)

    print("Reading crontab file...")
    lines = read_crontab(file_path)
    
    print("Removing existing latency-simula.py commands...")
    lines = remove_latency_simula(lines)
    
    print("Generating new cron commands...")
    times = generate_random_times(start_hour, end_hour, num_commands, min_interval, max_interval, offset)
    commands = generate_cron_commands(times)
    
    print("Writing new commands to crontab file...")
    lines.extend(commands)
    write_crontab(file_path, lines)
    
    print("=" * 40)
    print(f"Operation completed. END Time: {datetime.now()}")
    print("=" * 40)

if __name__ == "__main__":
    main()