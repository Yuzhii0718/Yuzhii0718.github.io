# PyQt6 Based GUI Notepad

## Description

This is a simple notepad application made using PyQt6. It has all the basic features of a notepad application.

## Usage

To run the application, run the following command in the terminal:

```bash
python Notepad.py
```