# coding:utf-8
"""
**************************************************
@File   ：PyQt6_QuickStart -> __init__
@IDE    ：PyCharm
@Author ：Yuzhii0718
@Date   ：2023/8/10 20:56
**************************************************
"""

from Part_3.notePadDemo import Ui_MainWindow
from Part_3 import notePadDemo
