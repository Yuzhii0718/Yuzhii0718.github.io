# PDBC in PyQt6

This item will show how to use the `mysql` module to connect to a database and insert data into a database.

## Installation

```bash
pip install mysql-connector-python
```

## modules

### dbConnectionDemo

This is a simple demo of how to connect to a database using the `mysql` module.

#### Usage

```bash
python dbConnectionDemo.py
```

### insertDemo

This is a simple demo of how to insert data into a database using the `mysql` module.

#### Usage

```bash
python insertDemo.py
```

### selectDemo

This is a simple demo of how to select data from a database using the `mysql` module.

#### Usage

```bash
python selectDemo.py
```

### searchDemo

This is a simple demo of how to search data from a database using the `mysql` module.

#### Usage

```bash
python searchDemo.py
```

### loginDemo

This is a simple demo of how to login using the `mysql` module.

#### Usage

```bash
python loginDemo.py
```
