IOWRT Airoha integration
IOWRT Airoha 集成
========================

This folder contains target recipes that have been backported from OpenWRT, then adapted and integrated into IOPSYSWRT. The target folder has been made IOWRT-specific so as not to conflict with existing OpenWRT support.
这个文件夹包含从 OpenWRT 回溯的目标方案，然后适配并集成到 IOPSYSWRT 中。目标文件夹已被制作成 IOWRT 特定的，以免与现有的 OpenWRT 支持冲突。

Moving from Airoha SDK to IOWRT
移植 Airoha SDK 到 IOWRT
===============================

Raw boards running Airoha SDK must be prepared before booting IOWRT image for first time.
在第一次启动 IOWRT 镜像之前，运行 Airoha SDK 的原始板必须先进行准备。

Backup important data
备份重要数据
---------------------

**Important:** As a first step backup the following and save it in a safe place (one folder per-device named after device MAC-address and/or serial number):
**重要：** 首先备份以下内容并将其保存在安全的地方（每个设备一个文件夹，命名为设备的 MAC 地址和/或序列号）：

Backup U-Boot environment (`fw_printenv` from Linux, `printenv` from U-Boot)
Backup U-Boot 环境（来自 Linux 的 `fw_printenv`，来自 U-Boot 的 `printenv`）

    ssh root@192.168.1.1 fw_printenv | tee u-boot-environment-dev-AA:BB:CC:DD:EE:FF.txt

First find out mtd-device of the `art`-partition which contains calibration data.
Depending on the SW running on the device, it may also be called `reservearea`.
首先找出包含校准数据的 `art` 分区的 mtd 设备。
根据设备上运行的 SW，它也可能被称为 `reservearea`。

    $ ssh root@192.168.1.1 cat /proc/mtd | grep -E '"art"|"reservearea"$'
    mtd8: 00193000 0001f000 "art"

Now backup that MTD-device:
现在备份该 MTD 设备：

    $ ssh root@192.168.1.1 dd if=/dev/mtdX bs=128K > art-dev-AA:BB:CC:DD:EE:FF.img
    12+1 records in
    12+1 records out

Install IOWRT on the target
安装 IOWRT 到目标
---------------------------

Run a TFTP-server on your PC and configure a static IP 192.168.1.100.
运行 TFTP 服务器在你的 PC 上并配置静态 IP

Copy (or symlink) files to tftproot. The commands below are only examples, make sure to use the right files matching your device and make sure you copy it to whatever your tftproot is.
复制（或符号链接）文件到 tftproot。下面的命令只是示例，确保使用与你的设备匹配的正确文件，并确保你复制到你的 tftproot。

    cp bin/targets/airoha/en7562/*-u-boot-nand.bin ~/tftp/tcboot.bin
    cp bin/targets/airoha/en7562/*-u-boot-nand.bin ~/tftp/u-boot-nand.bin
    cp bin/targets/airoha/en7562/last.itb ~/tftp/image.itb

Connect UART console.
连接 UART 控制台。

Login via one of these credentials
登录使用以下凭据之一

    telecomadmin / nE7jA%5m
    admin (or) root / 1234

In U-Boot, setup your local network. Note that it is mandatory to login to U-Boot, if U-Boot errored and drops you to a prompt, it is better to reboot and interrupt the boot, because even though it seemingly works, it will behave very erratically if one has not logged in.
在 U-Boot 中，设置你的本地网络。注意，登录到 U-Boot 是强制性的，如果 U-Boot 出错并将你丢到提示符，最好重启并中断启动，因为即使它看起来工作正常，如果没有登录，它会表现得非常不稳定。

    ECNT> setenv serverip 192.168.1.100; setenv ipaddr 192.168.1.1; ping 192.168.1.100

Double-check that you have read the note above, marked with "**Important:**" and that you have really backed up both U-Boot env and art (calibration data).
如果你没有备份 U-Boot 环境和 art（校准数据），请不要继续。

Upload the new bootloader once via TFTP from the PC to the target. The filename has to be `tcboot.bin`.
上传新的引导加载程序一次通过 TFTP 从 PC 到目标。文件名必须是 `tcboot.bin`。

    $ cd ~/tftp && tftp 192.168.1.1
    tftp> mode binary
    tftp> put tcboot.bin

After the `put tcboot.bin` has completed, the serial console should print that U-Boot has been flashed successfully.
然后 `put tcboot.bin` 完成后，串行控制台应该会打印出 U-Boot 已成功刷新。

    Start Tftp handler
    Using ecnt_eth device
    Listening for TFTP transfer on 192.168.1.1
    Load address: 0x81800000
    Loading: #################################################################
            ######################################
            17.6 KiB/s
    done
    Bytes transferred = 524288 (80000 hex)
    CRC check success, start imageUpgrade
    erase: addr=0x0, len=0x80000
    write: src=0x81800000, len=0x80000, dst=0x0
    ............upgrade finished !

If successful, reboot the board:
如果成功，重启主板：

    ECNT> reset
    resetting ...

The board will reboot into a new U-Boot version.
随后主板将重启到新的 U-Boot 版本。

    Secure key does not exist

    EN7523DRAMC V0.5
    dram_type = 5, speed = 1866
    Final Impdance Cal Result: OCDP:0xa, OCDN:0xa, ODTP:0xa, ODTN:0xa
    DDR1866 PLL setting init
    [Dramc] PCDDR3 AC Timing update
    Fire MRW command...
    ModeReg.2, value.0x20 done
    Fire MRW command...
    ModeReg.3, value.0x0 done
    Fire MRW command...
    ModeReg.1, value.0x6 done
    Fire MRW command...
    ModeReg.0, value.0x1114 done
    Fire MRW command...
    ModeReg.1, value.0x86 done
    Fire MRW command...
    ModeReg.1, value.0x6 done
    Calculate size.
    DRAM size=256MB


    U-Boot 2022.04-OpenWrt-r19426-2b1941e47d-00028-gbceaa7a9cf-dirty (Aug 16 2022 - 07:52:30 +0000)

    CPU:   Econet EN7529DU
    DRAM:  240 MiB
    Core:  4 devices, 4 uclasses, devicetree: embed
    spi-nand: spi_nand spinand@0: Micron SPI NAND was found.
    spi-nand: spi_nand spinand@0: 256 MiB, block size: 128 KiB, page size: 2048, OOB size: 128
    Reserve nand block at 0x0eba0000 for tcboot's BBT
    Reserve nand block at 0x0ffe0000 for tcboot's BMT
    + 0x000000000000-0x000010000000 : "spi-nand0"
    + 0x000000000000-0x000000100000 : "u-boot"
    + 0x000000100000-0x000000280000 : "reserved"
    + 0x000000280000-0x000010000000 : "ubi"
    Loading Environment from UBI... ubi0: default fastmap pool size: 100
    ubi0: default fastmap WL pool size: 50
    ubi0: attaching mtd3
    ubi0 error: scan_peb: bad image sequence number 636566866 in PEB 1356, expected 479597776
    Erase counter header dump:
            magic          0x55424923
            version        1
            ec             4
            vid_hdr_offset 2048
            data_offset    4096
            image_seq      636566866
            hdr_crc        0x204dea5a
    erase counter header hexdump:
    00000000: 55 42 49 23 01 00 00 00 00 00 00 00 00 00 00 04 00 00 08 00 00 00 10 00 25 f1 3d 52 00 00 00 00  UBI#....................%.=R....
    00000020: 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 20 4d ea 5a  ............................ M.Z
    ubi0 error: ubi_attach_mtd_dev: failed to attach mtd3, error -22
    UBI error: cannot attach mtd3
    UBI error: cannot initialize UBI, error -22
    UBI init error 22
    Please check, if the correct MTD partition is used (size big enough?)

    ** Cannot find mtd partition "ubi"
    In:    serial@1fbf0000
    Out:   serial@1fbf0000
    Err:   serial@1fbf0000
    CPU0: found redistributor 0 region 0:0x0000000009080000
    Net:   en75xx-eth
    Hit any key to stop autoboot:  0
    =>

After the device has restarted, initialise UBI as follows:
之后设备重启后，按照以下步骤初始化 UBI：

    => run format_ubi
    Erasing 0x00000000 ... 0x0fd7ffff (2028 eraseblock(s))
    Skipping bad block at 0x0e920000
    Skipping bad block at 0x0fd60000
    ubi0: default fastmap pool size: 100
    ubi0: default fastmap WL pool size: 50
    ubi0: attaching mtd3
    ubi0: scanning is finished
    ubi0: empty MTD device detected
    ubi0: attached mtd3 (name "ubi", size 253 MiB)
    ubi0: PEB size: 131072 bytes (128 KiB), LEB size: 126976 bytes
    ubi0: min./max. I/O unit sizes: 2048/2048, sub-page size 2048
    ubi0: VID header offset: 2048 (aligned 2048), data offset: 4096
    ubi0: good PEBs: 2026, bad PEBs: 2, corrupted PEBs: 0
    ubi0: user volume: 0, internal volumes: 1, max. volumes count: 128
    ubi0: max/mean erase counter: 0/0, WL threshold: 4096, image sequence number: 0
    ubi0: available PEBs: 1982, total reserved PEBs: 44, PEBs reserved for bad PEB handling: 38
    Creating dynamic volume env1 of size 126976
    Creating dynamic volume env2 of size 126976
    Creating dynamic volume boot1 of size 5242880
    Creating dynamic volume boot2 of size 5242880
    Creating dynamic volume rootfs1 of size 73400320
    Creating dynamic volume rootfs2 of size 73400320
    Creating dynamic volume overlay1 of size 20971520
    Creating dynamic volume overlay2 of size 20971520
    Creating dynamic volume art of size 1572864
    Saving Environment to UBI... ubi0: detaching mtd3
    ubi0: mtd3 is detached
    ubi0: default fastmap pool size: 100
    ubi0: default fastmap WL pool size: 50
    ubi0: attaching mtd3
    ubi0: scanning is finished
    ubi0: attached mtd3 (name "ubi", size 253 MiB)
    ubi0: PEB size: 131072 bytes (128 KiB), LEB size: 126976 bytes
    ubi0: min./max. I/O unit sizes: 2048/2048, sub-page size 2048
    ubi0: VID header offset: 2048 (aligned 2048), data offset: 4096
    ubi0: good PEBs: 2026, bad PEBs: 2, corrupted PEBs: 0
    ubi0: user volume: 9, internal volumes: 1, max. volumes count: 128
    ubi0: max/mean erase counter: 2/1, WL threshold: 4096, image sequence number: 0
    ubi0: available PEBs: 393, total reserved PEBs: 1633, PEBs reserved for bad PEB handling: 38
    Writing to redundant UBI... done
    OK

After that, run the following command to flash kernel and rootfs, the ITB-image must available as `image.itb`:
之后，运行以下命令以刷新内核和根文件系统，ITB 镜像必须可用为 `image.itb`：

    => run update_itb_all 
    Not found TC Phy
    Not found TC Phy
    Not found TC Phy
    Not found TC Phy
    Using en75xx-eth device
    TFTP from server 192.168.1.100; our IP address is 192.168.1.1
    Filename 'image.itb'.
    Load address: 0x80500000
    Loading: ##################################################  18 MiB
            507.8 KiB/s
    done
    Bytes transferred = 18880804 (1201924 hex)
    ## Copying 'bootloader' subimage from FIT image at 80500000 ...
    sha256+ Erasing 0x00000000 ... 0x000fffff (8 eraseblock(s))
    Size not on a page boundary (0x800), rounding to 0x80800
    Writing 526336 byte(s) (257 page(s)) at offset 0x00000000
    ## Copying 'boot' subimage from FIT image at 80500000 ...
    sha256+ Remove UBI volume boot1 (id 2)
    Creating dynamic volume boot1 of size 3551472
    3551472 bytes written to volume boot1
    ## Copying 'rootfs' subimage from FIT image at 80500000 ...
    sha256+ Remove UBI volume rootfs1 (id 4)
    Creating dynamic volume rootfs1 of size 14800574
    14800574 bytes written to volume rootfs1
    ## Copying 'boot' subimage from FIT image at 80500000 ...
    sha256+ Remove UBI volume boot2 (id 3)
    Creating dynamic volume boot2 of size 3551472
    3551472 bytes written to volume boot2
    ## Copying 'rootfs' subimage from FIT image at 80500000 ...
    sha256+ Remove UBI volume rootfs2 (id 5)
    Creating dynamic volume rootfs2 of size 14800574
    14800574 bytes written to volume rootfs2
    Saving Environment to UBI... ubi0: detaching mtd2
    ubi0: mtd2 is detached
    ubi0: default fastmap pool size: 100
    ubi0: default fastmap WL pool size: 50
    ubi0: attaching mtd2
    ubi0: scanning is finished
    ubi0: attached mtd2 (name "ubi", size 255 MiB)
    ubi0: PEB size: 131072 bytes (128 KiB), LEB size: 126976 bytes
    ubi0: min./max. I/O unit sizes: 2048/2048, sub-page size 2048
    ubi0: VID header offset: 2048 (aligned 2048), data offset: 4096
    ubi0: good PEBs: 2038, bad PEBs: 2, corrupted PEBs: 0
    ubi0: user volume: 10, internal volumes: 1, max. volumes count: 128
    ubi0: max/mean erase counter: 2/1, WL threshold: 4096, image sequence number: 0
    ubi0: available PEBs: 1323, total reserved PEBs: 715, PEBs reserved for bad PEB handling: 38
    Writing to UBI... done
    OK

Now set important U-Boot variables (examples only). `boardid` needs to correspond to a filename in feeds/targets/airoha/base-files/etc/board-db/boards/. MAC-Address needs to be the base MAC-address of the board. Another variable to set is `serial_number` (if it was included in the old U-Boot environment).
现在设置重要的 U-Boot 变量（仅示例）。`boardid` 需要与 feeds/targets/airoha/base-files/etc/board-db/boards/ 中的文件名相对应。MAC 地址需要是板的基本 MAC 地址。另一个需要设置的变量是 `serial_number`（如果它包含在旧的 U-Boot 环境中）。

    => env set boardid en7523_evb
    => env set ethaddr AA:BB:CC:DD:EE:FF
    => env save

Load ART-partition-backup into RAM
加载 ART 分区备份到 RAM

    => tftpboot art.img
    en75xx-eth-sw uses internal switch
    Not found TC Phy
    Not found TC Phy
    Not found TC Phy
    Not found TC Phy
    Using en75xx-eth device
    TFTP from server 192.168.1.100; our IP address is 192.168.1.1
    Filename 'art.img'.
    Load address: 0x80500000
    Loading: ##################################################  1.5 MiB
            201.2 KiB/s
    done
    Bytes transferred = 1572864 (180000 hex)

Write ART to UBI:
写入 ART 到 UBI

    => ubi write ${loadaddr} art ${filesize}
    1572864 bytes written to volume art

Reboot the board, it should boot into IOWRT.
重启主板，它应该会启动到 IOWRT。

    => reset

Network configuration
网络配置
--

under construction  
在建构中
<!---
The machine can act as a router, provided there is an USB dongle with the right driver (right now, the kernel is configured to ship with the RTL8169 driver for USB-Ethernet dongles using this chipset).
Networking is configured as follows:
- By default, there is a DHCP server listening on the integrated Ethernet port for any requests, if any. From that interface, the device is reachable on address 192.168.1.1.
- If there is an USB Ethernet dongle attached to the board, it will be automatically configured to ask for an IP address with DHCP from the network.
- The kernel also ships with drivers for the wireless hardware in the device. The wireless interface can be configured either in AP or STA mode.

这个机器可以作为路由器，只要有一个带有正确驱动程序的 USB 加密狗（目前，内核配置为使用 RTL8169 驱动程序来支持使用此芯片组的 USB-Ethernet 加密狗）。
网络配置如下：
- 默认情况下，集成以太网端口上有一个 DHCP 服务器监听任何请求。如果有的话，从该接口可以在地址 192.168.1.1 上访问设备。
- 如果有一个 USB 以太网加密狗连接到主板，它将被自动配置为从网络请求 IP 地址。
- 内核还带有设备中无线硬件的驱动程序。无线接口可以配置为 AP 或 STA 模式。
-->

Compiling an IOPSYSWRT OS image
编译 IOPSYSWRT OS 镜像
--

To compile an image targeting the en7562, type in these commands:
为了编译一个针对 en7562 的镜像，请输入以下命令：

```
git clone git@dev.iopsys.eu:iopsys/iopsyswrt.git
cd iopsyswrt
./iop setup_host
./iop bootstrap
./iop feeds_update
./iop genconfig --boards
./iop genconfig <boardname>

make -j[nr_threads]
```

This should generate flashable FIT image in `bin/targets/airoha/en7562`.
这应该会在 `bin/targets/airoha/en7562` 中生成可刷写的 FIT 镜像。

**Only tclinux image is supported at the moment**
**目前只支持 tclinux 镜像**

Flashing an IOPSYSWRT OS image
刷写 IOPSYSWRT OS 镜像
--

To flash an image from **linux console**, type in this command:
为了从 **linux 控制台** 刷写镜像，请输入以下命令：

```  
scp ./bin/targets/airoha/en7562/last.itb root@<board>:/tmp 
```

and on the \<board\> (ssh \<board\>)  
以及在 \<board\> 上（ssh \<board\>）：

```
[...]  
root@iopsys:~# sysupgrade /tmp/last.itb  
```

# Airoha Specific Environment Parameters
# Airoha 特定环境参数

| Parameter | Description                                                           | Valid Values | Default Value |
|-----------|-----------------------------------------------------------------------|--------------|---------------|
| wan_mode  | Determines if the device should operate in PON or Active Ethernet mode | pon, ae_wan  | pon           |
| onu_type  | Determines if the PON device should operate in 1:SFU or 2:HGU mode     | 1, 2         | 2             |

## Usage
## 用法

### From userspace
### 在用户空间

~# fw_setenv |PARAMETER| |VALUE|

### From u-boot
### 从 u-boot

=> env set |PARAMETER| |VALUE|<br>
=> env save

Flash Layout
刷写布局
--

under construction  
在建构中
<!---
[    4.066555] parsing <1m[bootloader]a,64m[ioplinux]a,-[free]a>  
[    4.073744] partition 2: name <free>, offset ffffffff, size ffffffff, mask flags 0  
[    4.081288] partition 1: name <ioplinux>, offset ffffffff, size 4000000, mask flags 0  
[    4.089096] partition 0: name <bootloader>, offset ffffffff, size 100000, mask flags 0  
[    4.097000] Creating 4 MTD partitions on "EN7512-SPI_NAND":  
[    4.102560] 0x000000000000-0x000000100000 : "bootloader"  
[    4.108663] 0x000000100000-0x000004100000 : "ioplinux"  
[    4.114635] 0x000004100000-0x00000de80000 : "free"  
[    4.120520] 0x00000de80000-0x00000e000000 : "art"  
-->
<!---
root@iopsys:~# cat /proc/mtd  
dev:    size   erasesize  name  
mtd0: 00100000 00020000 "bootloader"  
mtd1: 04000000 00020000 "ioplinux"  
mtd2: 09d80000 00020000 "free"  
mtd3: 00180000 00020000 "art"  
-->

Working with UBIFS
工作在 UBIFS
--

under construction  
在建构中
<!---
Ubi volume preparation:  
root@iopsys:~# ubiformat /dev/mtd2  
root@iopsys:~# ubiattach -p /dev/mtd2  
root@iopsys:~# ubimkvol /dev/ubi0 -N data -s 128MiB  
root@iopsys:~# mkdir /opt  
root@iopsys:~# mount -t ubifs ubi0:data /opt  
-->
<!---
Accessing ubi volume:  
root@iopsys:~# mkdir /opt  
root@iopsys:~# ubiattach -p /dev/mtd2  
root@iopsys:~# mount -t ubifs ubi0:data /opt  
-->
