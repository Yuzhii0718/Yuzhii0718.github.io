# 关于

右侧 banner 使用的图片素材来音乐专辑封面。
应用中心 中的部分网页程序来自外部。
遵循 [BY-NC-SA协议](https://creativecommons.org/licenses/by-nc-sa/4.0/)

---

> "Freedom is the alone unoriginated birthright of man, and belongs to him by force of his humanity; and is independence on the will and co-action of every other in so far as this consists with every other person’s freedom."
The Metaphysics of Ethics by Immanuel Kant
